<?php
/**
 * Template Name: Työelämä & yrittäjyys
 *
 * @package sami-elmeranta
 */

get_header();
the_post();

se_page_hero( 'Työelämä & yrittäjyys', 'Monipuolinen työkokemus ja yrittäjyystausta antaa hyvät eväät politiikkaan', 'Työurani alkoi ruokavaraston kassalta ja jatkui rautakaupan myyjänä, kokoonpanolinjalla ja ravintola-alalla. Nykyään johdan myyntiä ja toimin osakkaana sekä freelancerina.' );
?>

<section class="pb-4" aria-label="Nosto">
	<div class="container-site max-w-4xl">
		<div class="relative flex items-center gap-4 overflow-hidden rounded-3xl bg-gradient-to-br from-brand via-liila to-ink-soft p-5 sm:gap-5 text-white shadow-xl sm:p-8" data-reveal="zoom">
			<div class="pointer-events-none absolute -right-10 -top-10 size-40 rounded-full bg-white/10 blur-2xl animate-blob" aria-hidden="true"></div>
			<span class="relative grid size-12 shrink-0 place-items-center rounded-2xl bg-white/15 sm:size-14"><?php se_the_icon( 'lucide:briefcase', 'size-7' ); ?></span>
			<div class="relative">
				<p class="font-display text-xl font-bold leading-snug sm:text-3xl">Toimin tällä hetkellä osakkaana kolmessa mikroyrityksessä</p>
				<p class="mt-4 flex flex-wrap gap-2">
					<a href="https://www.tilihub.fi/" target="_blank" rel="noopener" class="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-2 text-sm font-semibold text-white ring-1 ring-white/25 transition hover:-translate-y-0.5 hover:bg-white hover:text-brand-dark">tilihub.fi <?php se_the_icon( 'lucide:arrow-up-right', 'size-4' ); ?><span class="sr-only"> (avautuu uuteen ikkunaan)</span></a>
					<a href="https://www.ikkunakauppias.fi/" target="_blank" rel="noopener" class="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-2 text-sm font-semibold text-white ring-1 ring-white/25 transition hover:-translate-y-0.5 hover:bg-white hover:text-brand-dark">ikkunakauppias.fi <?php se_the_icon( 'lucide:arrow-up-right', 'size-4' ); ?><span class="sr-only"> (avautuu uuteen ikkunaan)</span></a>
				</p>
			</div>
		</div>
	</div>
</section>

<section class="py-12" aria-labelledby="ura-title">
	<div class="container-site max-w-4xl">
		<?php se_section_head( array( 'id' => 'ura-title', 'eyebrow' => 'Työura', 'title' => 'Kokemusta myynnistä, johtamisesta ja yrittämisestä' ) ); ?>
		<ol class="relative mt-14 space-y-10 before:absolute before:inset-y-2 before:left-[0.6rem] before:w-0.5 before:bg-gradient-to-b before:from-brand before:via-brand-light before:to-line sm:before:left-[9.6rem]">
			<?php foreach ( se_content( 'career' ) as $c ) : ?>
				<li class="relative grid gap-2 pl-10 sm:grid-cols-[8rem_1fr] sm:gap-10 sm:pl-0" data-reveal>
					<span class="absolute left-0 top-1.5 size-5 rounded-full border-4 border-white bg-brand shadow sm:left-[9rem]" aria-hidden="true"></span>
					<p class="text-sm font-semibold text-muted sm:pt-1 sm:text-right"><?php echo esc_html( $c['period'] ); ?></p>
					<div class="sm:pl-10">
						<h3 class="text-xl font-bold"><?php echo esc_html( $c['title'] ); ?></h3>
						<p class="font-semibold text-brand-dark"><?php echo esc_html( $c['org'] ); ?></p>
						<p class="mt-2 text-muted"><?php echo esc_html( $c['text'] ); ?></p>
					</div>
				</li>
			<?php endforeach; ?>
		</ol>
		<p class="mt-14 rounded-3xl bg-mist p-6 text-lg text-muted" data-reveal>Edellä mainittujen lisäksi minulla on ollut useita osakasrooleja ja asiantuntijapositioita eri yrityksissä. Nykyään toimin osakkaana kolmessa mikroyrityksessä ja teen freelancerina erilaisia asiantuntijatöitä.</p>
	</div>
</section>

<?php get_template_part( 'template-parts/page-extra' ); ?>

<section class="bg-mist py-24" aria-labelledby="kollegat-title">
	<div class="container-site">
		<?php se_section_head( array( 'id' => 'kollegat-title', 'eyebrow' => 'Suosittelut', 'title' => 'Kollegoiden sanoin' ) ); ?>
		<div class="mt-12"><?php se_testimonials( se_content( 'workTestimonials' ) ); ?></div>
	</div>
</section>

<?php
get_footer();
