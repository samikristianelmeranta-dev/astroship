/* Nordic CRM – henkilökunnan sovellus. Tiedot haetaan /wp-json/nap/v1/ -rajapinnasta. */
(function () {
  'use strict';
  var C = window.NAP || {};
  var main = document.getElementById('main');
  var S = { me: null, users: [], stages: [], today: '', board: [], tasks: [], customers: [], taskFilter: 'omat', q: '', src: '' };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function eur(n) { return Math.round(+n || 0).toLocaleString('fi-FI') + ' €'; }
  function fdate(d) { if (!d) return ''; var p = String(d).slice(0, 10).split('-'); return (+p[2]) + '.' + (+p[1]) + '.' + (p[0] !== S.today.slice(0, 4) ? p[0] : ''); }
  function ftime(dt) { if (!dt) return ''; return fdate(dt) + ' klo ' + String(dt).slice(11, 16).replace(':', '.'); }
  function user(id) { for (var i = 0; i < S.users.length; i++) if (S.users[i].id === id) return S.users[i]; return null; }
  function uname(id) { var u = user(id); return u ? u.name : ''; }
  function isOwner() { return S.me && S.me.role === 'osakas'; }
  function toast(m, err) { var t = document.getElementById('toast'); t.textContent = m; t.className = 'toast on' + (err ? ' err' : ''); clearTimeout(t._h); t._h = setTimeout(function () { t.className = 'toast'; }, 2800); }

  function api(path, opts) {
    opts = opts || {};
    var init = { method: opts.method || 'GET', credentials: 'same-origin', headers: { 'X-WP-Nonce': C.nonce } };
    if (opts.form) init.body = opts.form; // tiedostot (FormData)
    else if (opts.body) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
    return fetch(C.root + path, init).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error((j && j.message) || 'Toiminto epäonnistui (' + r.status + ').'); throw e; }
        return j;
      });
    });
  }
  function fail(e) { toast(e.message || 'Toiminto epäonnistui.', true); }

  /* ---------- Navigaatio ---------- */
  var VIEWS = [
    ['paiva', 'Oma päivä', 'M3 12l9-8 9 8M5 10v10h14V10'],
    ['putki', 'Myyntiputki', 'M4 5h4v14H4zM10 5h4v9h-4zM16 5h4v6h-4z'],
    ['kalenteri', 'Kalenteri', 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4'],
    ['asiakkaat', 'Asiakkaat', 'M16 11a4 4 0 10-8 0 4 4 0 008 0zM4 21c1-4 4-6 8-6s7 2 8 6'],
    ['tehtavat', 'Tehtävät', 'M4 6l2 2 4-4M4 14l2 2 4-4M13 6h7M13 14h7'],
    ['laskuri', 'Laskuri', 'M6 3h12v18H6zM9 7h6M9 12h.01M12 12h.01M15 12h.01M9 16h.01M12 16h.01M15 16h.01'],
    ['saapuneet', 'Saapuneet', 'M3 6h18v12H3zM3 7l9 6 9-6'],
    ['uusi', 'Uusi tarjouspyyntö', 'M12 5v14M5 12h14']
  ];
  function route() { var h = (location.hash || '#paiva').slice(1); var m = /^asiakas-(\d+)$/.exec(h); if (m) return { v: 'asiakkaat', id: +m[1] }; m = /^uusi-(\d+)$/.exec(h); if (m) return { v: 'uusi', id: +m[1] }; m = /^saapunut-(\d+)$/.exec(h); if (m) return { v: 'saapuneet', id: +m[1] };
    m = /^kalenteri-(\d{4}-\d{2}-\d{2})$/.exec(h); if (m) return { v: 'kalenteri', week: m[1] };
    m = /^kaynti-(\d+)$/.exec(h); return m ? { v: 'kalenteri', visit: +m[1] } : { v: h || 'paiva' }; }
  function drawNav(v) {
    var open = S.tasks.filter(function (t) { return t.assignee_id === S.me.id && !t.done; }).length;
    document.getElementById('nav').innerHTML = VIEWS.filter(function (x) { return x[0] !== 'saapuneet' || isOwner(); }).map(function (x) {
      return '<a href="#' + x[0] + '" class="' + (x[0] === v ? 'on' : '') + '"' + (x[0] === v ? ' aria-current="page"' : '') + '><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + x[2] + '"/></svg>' + x[1] + (x[0] === 'tehtavat' && open ? '<span class="cnt">' + open + '</span>' : '') + (x[0] === 'saapuneet' && S.inboxNew ? '<span class="cnt">' + S.inboxNew + '</span>' : '') + '</a>';
    }).join('');
    document.getElementById('who').innerHTML = '<b>' + esc(S.me.name) + '</b>' + (isOwner() ? 'Osakas' : 'Asentaja') +
      (C.admin ? ' · <a href="' + esc(C.admin) + '">Asetukset</a>' : '') + ' · <a href="' + esc(C.logout) + '">Kirjaudu ulos</a>';
  }
  function head(title, sub, right) { return '<div class="head"><div><h1>' + esc(title) + '</h1>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</div>' + (right || '') + '</div>'; }

  /* ---------- Tehtävärivi ---------- */
  function taskRow(t) {
    var late = !t.done && t.due_date && t.due_date < S.today, today = t.due_date === S.today;
    return '<div class="task ' + (t.done ? 'done' : '') + '"><input type="checkbox" data-task="' + t.id + '" ' + (t.done ? 'checked' : '') + ' aria-label="Merkitse tehdyksi: ' + esc(t.title) + '">' +
      '<div><div class="t">' + esc(t.title) + '</div><div class="m">' + (t.customer_id ? '<a href="#asiakas-' + t.customer_id + '">' + esc(t.customer) + '</a>' + (t.address ? ' · ' + esc(t.address) : '') : '') + '</div></div>' +
      '<div class="r"><div>' + (late ? '<span class="pill crit">Myöhässä ' + fdate(t.due_date) + '</span>' : today ? '<span class="pill gold">Tänään</span>' : esc(fdate(t.due_date))) + '</div><div class="muted" style="margin-top:3px">' + esc((uname(t.assignee_id) || '').split(' ')[0]) + '</div></div></div>';
  }
  document.addEventListener('change', function (e) {
    var id = e.target.getAttribute && e.target.getAttribute('data-task');
    if (!id) return;
    var done = e.target.checked;
    api('tasks/' + id, { method: 'POST', body: { done: done } }).then(function (t) {
      S.tasks = S.tasks.map(function (x) { return x.id === t.id ? t : x; });
      toast(done ? 'Tehtävä merkitty tehdyksi' : 'Tehtävä palautettu');
      render();
    }).catch(function (err) { e.target.checked = !done; fail(err); });
  });

  /* ---------- Näkymät ---------- */
  function viewDay() {
    var mine = S.tasks.filter(function (t) { return t.assignee_id === S.me.id && !t.done; });
    var late = mine.filter(function (t) { return t.due_date && t.due_date < S.today; }).length;
    var offers = S.board.filter(function (p) { return p.stage === 2; });
    var running = S.board.filter(function (p) { return p.stage >= 3 && p.stage < 6; });
    var fresh = S.board.filter(function (p) { return p.stage === 0; });
    var tiles = [
      ['Omat tehtävät', mine.length, late ? late + ' myöhässä' : 'ei myöhässä olevia'],
      ['Uudet tarjouspyynnöt', fresh.length, 'odottaa yhteydenottoa'],
      ['Avoimet tarjoukset', offers.length, eur(offers.reduce(function (a, p) { return a + p.value; }, 0)) + ' odottaa'],
      ['Käynnissä', running.length, 'hyväksytty → asennus']
    ];
    var warn = S.me.twofa === false ? '<div class="warn">Kaksivaiheinen tunnistautuminen ei ole käytössä tunnuksellasi. Ota se käyttöön profiilistasi.</div>' : '';
    var VV = window.NAPV.visits;
    if (VV && !S.visitsToday) { S.visitsToday = []; VV.loadToday().then(function () { if (route().v === 'paiva') viewDay(); }).catch(function () {}); }
    main.innerHTML = head('Hei, ' + S.me.name.split(' ')[0], 'Tehtävät ja tilanne yhdellä silmäyksellä') + warn + (VV ? VV.todayBlock() : '') +
      '<div class="grid g4">' + tiles.map(function (x) { return '<div class="card tile"><div class="lbl">' + x[0] + '</div><div class="val num">' + x[1] + '</div><div class="sub">' + esc(x[2]) + '</div></div>'; }).join('') + '</div>' +
      '<div class="grid g2" style="margin-top:14px"><div class="card"><h2>Omat tehtävät <span class="r muted">' + mine.length + ' avointa</span></h2>' +
      (mine.length ? mine.map(taskRow).join('') : '<div class="empty">Ei avoimia tehtäviä.</div>') + '</div>' +
      '<div class="card"><h2>Uusimmat tarjouspyynnöt</h2>' + (fresh.length ? fresh.slice(0, 6).map(function (p) {
        return '<div class="task" style="grid-template-columns:minmax(0,1fr) auto"><div><div class="t"><a href="#asiakas-' + p.customer_id + '">' + esc(p.customer) + '</a></div><div class="m">' + esc(p.title) + (p.address ? ' · ' + esc(p.address) : '') + '</div></div><div class="r muted">' + esc(fdate(p.updated_at)) + '</div></div>';
      }).join('') : '<div class="empty">Ei uusia tarjouspyyntöjä.</div>') + '</div></div>';
  }

  function viewBoard() {
    // Tilaus-vaihe (4) näytetään Hyväksytty-sarakkeessa: kohde etenee kortin vaiheiden kautta.
    var cols = S.stages.map(function (s, i) { return i; }).filter(function (i) { return i !== 4; });
    main.innerHTML = head('Myyntiputki', 'Kohteet vaiheen mukaan. Avaa kohde, niin näet seuraavan toimenpiteen.') +
      '<div class="board">' + cols.map(function (i) {
        var s = S.stages[i];
        var items = S.board.filter(function (p) { return p.stage === i || (i === 3 && p.stage === 4); });
        var sum = items.reduce(function (a, p) { return a + p.value; }, 0);
        return '<div class="col"><h3><span>' + esc(s) + '</span><span class="muted num">' + items.length + '</span></h3><div class="sum num">' + (sum ? eur(sum) : '') + '</div>' +
          items.map(function (p) {
            var o = user(p.owner_id);
            return '<div class="deal" data-cust="' + p.customer_id + '" tabindex="0" role="link"><b>' + esc(p.customer) + '</b><div class="m">' + esc(p.address) + '</div><div class="m">' + esc(p.title) + '</div>' + (p.delivery && p.delivery !== 'asennus' ? '<div class="m"><span class="pill gold">' + esc(p.delivery === 'omat_mitat' ? 'Omat mitat' : 'Ilman asennusta') + '</span></div>' : '') +
              '<div class="f"><span class="num small">' + (p.value ? eur(p.value) : '–') + '</span><span style="display:flex;gap:4px;align-items:center">' + (o ? '<span class="av" title="' + esc(o.name) + '">' + esc(o.ini) + '</span>' : '') + '</span></div></div>';
          }).join('') + (items.length ? '' : '<div class="muted small" style="padding:6px">Ei kohteita</div>') + '</div>';
      }).join('') + '</div>';
  }
  main.addEventListener('click', function (e) {
    var mv = e.target.closest('[data-mv]');
    if (mv) {
      e.stopPropagation();
      var p = S.board.filter(function (x) { return x.id === +mv.getAttribute('data-mv'); })[0];
      if (p.stage === 2 && !p.approval) { S.openApprove = p.id; location.hash = 'asiakas-' + p.customer_id; return; }
      if (p.stage === 1 && !p.offer) { S.openOffer = p.id; location.hash = 'asiakas-' + p.customer_id; return; }
      mv.disabled = true;
      api('projects/' + p.id, { method: 'POST', body: { stage: p.stage + 1 } }).then(function (np) {
        p.stage = np.stage; toast(p.customer + ' → ' + S.stages[np.stage]); render();
      }).catch(function (err) { mv.disabled = false; fail(err); });
      return;
    }
    var d = e.target.closest('[data-cust]');
    if (d) location.hash = 'asiakas-' + d.getAttribute('data-cust');
  });
  main.addEventListener('keydown', function (e) { var d = e.target.closest && e.target.closest('[data-cust]'); if (d && e.key === 'Enter') location.hash = 'asiakas-' + d.getAttribute('data-cust'); });

  function loadCustomers() {
    return api('customers' + (S.q ? '?q=' + encodeURIComponent(S.q) : '')).then(function (l) { S.customers = l; });
  }
  function viewCustomers(id) {
    var srcs = []; S.customers.forEach(function (c) { if (c.source && srcs.indexOf(c.source) < 0) srcs.push(c.source); });
    var list = S.customers.filter(function (c) { return !S.src || c.source === S.src; });
    if (!id && list[0] && window.innerWidth > 860) id = list[0].id;
    main.innerHTML = head('Asiakkaat', 'Yhteystiedot, kohteet ja koko historia', '<a class="btn p" href="#uusi">+ Uusi tarjouspyyntö</a>') +
      '<div class="cust"><div class="card"><div class="search"><input id="q" type="search" placeholder="Hae nimellä, osoitteella tai puhelimella" aria-label="Hae asiakasta" value="' + esc(S.q) + '">' +
      '<select id="src" aria-label="Lähde"><option value="">Kaikki lähteet</option>' + srcs.map(function (s) { return '<option ' + (s === S.src ? 'selected' : '') + '>' + esc(s) + '</option>'; }).join('') + '</select></div>' +
      (isOwner() && list.length ? '<div class="selbar"><label><input type="checkbox" id="selall"> Valitse kaikki</label><button type="button" class="btn sm danger" id="seldel" hidden>Poista valitut</button></div>' : '') +
      '<div class="clist">' + (list.length ? list.map(function (c) {
        var row = '<a href="#asiakas-' + c.id + '" class="' + (c.id === id ? 'on' : '') + '"><span><b>' + esc(c.name) + '</b><span class="small muted">' + esc(c.address || c.email) + '</span></span><span class="pill ' + (c.stage === 6 ? 'good' : c.stage === 2 ? 'gold' : '') + '">' + esc(S.stages[c.stage]) + '</span></a>';
        return isOwner() ? '<div class="selrow"><input type="checkbox" data-sel="' + c.id + '" aria-label="Valitse ' + esc(c.name) + '">' + row + '</div>' : row;
      }).join('') : '<div class="empty">Ei asiakkaita. Uudet tarjouspyynnöt tulevat tänne automaattisesti.</div>') + '</div></div>' +
      '<div class="card" id="ccard">' + (id ? '<p class="muted">Ladataan…</p>' : '<div class="empty">Valitse asiakas listasta.</div>') + '</div></div>';
    var q = document.getElementById('q'), t;
    q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { S.q = q.value.trim(); loadCustomers().then(function () { viewCustomers(route().id); var n = document.getElementById('q'); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }); }, 300); });
    document.getElementById('src').addEventListener('change', function (e) { S.src = e.target.value; viewCustomers(route().id); });
    bindSelection(main, '[data-sel]', 'selall', 'seldel', function (ids) {
      if (!confirm('Poistetaanko ' + ids.length + ' asiakasta pysyvästi kaikkine tietoineen (kohteet, tehtävät, historia, kuvat)? Tätä ei voi perua.')) return;
      deleteCustomers(ids);
    });
    if (id) loadCard(id);
  }

  /* ---------- Valintaruudut ja poisto (roskaposti, testit) ---------- */
  function bindSelection(root, sel, allId, btnId, onGo, label) {
    var btn = document.getElementById(btnId), all = document.getElementById(allId);
    if (!btn) return;
    var boxes = function () { return Array.prototype.slice.call(root.querySelectorAll(sel)); };
    var upd = function () { var n = boxes().filter(function (b) { return b.checked; }).length; btn.hidden = !n; btn.textContent = (label || 'Poista valitut') + ' (' + n + ')'; };
    boxes().forEach(function (b) { b.addEventListener('change', upd); });
    if (all) all.addEventListener('change', function () { boxes().forEach(function (b) { b.checked = all.checked; }); upd(); });
    btn.addEventListener('click', function () { onGo(boxes().filter(function (b) { return b.checked; }).map(function (b) { return +b.getAttribute(sel.slice(1, -1)); })); });
  }
  function deleteCustomers(ids) {
    api('customers/delete', { method: 'POST', body: { ids: ids } }).then(function (r) {
      toast('Poistettu: ' + r.poistettu);
      return Promise.all([loadCustomers(), window.NAPV.reloadBoard()]);
    }).then(function () { location.hash = 'asiakkaat'; viewCustomers(); }).catch(fail);
  }

  function opt(users, sel, empty) {
    return (empty ? '<option value="0">' + esc(empty) + '</option>' : '') + users.map(function (u) { return '<option value="' + u.id + '" ' + (u.id === sel ? 'selected' : '') + '>' + esc(u.name) + '</option>'; }).join('');
  }
  function loadCard(id) {
    api('customers/' + id).then(function (c) {
      var box = document.getElementById('ccard'); if (!box) return;
      var owners = S.users.filter(function (u) { return u.role === 'osakas'; });
      box.innerHTML =
        '<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><h2>' + esc(c.name) + '</h2><div class="small muted">' + esc([c.address, c.city].filter(Boolean).join(', ')) + '</div></div>' +
        '<span class="small muted">Asiakas ' + esc(fdate(c.created_at)) + ' alkaen</span></div>' +
        '<dl class="kv"><dt>Puhelin</dt><dd class="num">' + esc(c.phone || '–') + '</dd><dt>Sähköposti</dt><dd>' + esc(c.email || '–') + '</dd>' +
        '<dt>Lähde</dt><dd>' + esc(c.source || '–') + (c.referred_by ? ' · suositteli <a href="#asiakas-' + c.referred_by.id + '">' + esc(c.referred_by.name) + '</a>' : '') + '</dd>' +
        '<dt>Vastuumyyjä</dt><dd>' + (isOwner() ? '<select id="owner" aria-label="Vastuumyyjä">' + opt(owners, c.owner_id, 'Ei valittu') + '</select>' : esc(uname(c.owner_id) || '–')) + '</dd></dl>' +
        (c.projects.length ? c.projects.map(function (p) {
          return '<div class="proj" data-proj="' + p.id + '"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>' + esc(p.title) + '</b>' + (p.delivery !== 'asennus' ? '<span class="pill gold">' + esc(S.deliveries[p.delivery]) + '</span>' : '') + '</div>' +
            '<div class="small muted">' + esc(p.address) + '</div>' + (p.details ? '<div class="small" style="white-space:pre-line;margin-top:6px">' + esc(p.details) + '</div>' : '') +
            '<div class="offer-top" data-offw="' + p.id + '">' + (!p.approval ? '<button type="button" class="btn sm p" data-offer="' + p.id + '">' + (p.offer ? 'Tee päivitetty tarjous laskurilla' : 'Tee tarjous laskurilla') + '</button>' : '') + '</div>' +
            flowBox(p, c) +
            '<details class="more"><summary>Lisätiedot: arvo, asentaja, toimitustapa</summary><div class="fields" style="margin-top:10px">' +
            '<label class="fld">Arvo (€, sis. alv)<input data-f="value" type="number" min="0" step="10" value="' + (p.value || '') + '"></label>' +
            '<label class="fld">Asentaja<select data-f="installer_id">' + opt(S.users, p.installer_id, 'Ei valittu') + '</select></label>' +
            '<label class="fld">Toimitustapa<select data-f="delivery">' + Object.keys(S.deliveries).map(function (k) { return '<option value="' + k + '"' + (k === p.delivery ? ' selected' : '') + '>' + esc(S.deliveries[k]) + '</option>'; }).join('') + '</select></label>' +
            '<label class="fld">Vaihe (korjaa käsin)<select data-f="stage">' + S.stages.map(function (s, i) { return '<option value="' + i + '" ' + (i === p.stage ? 'selected' : '') + '>' + esc(s) + '</option>'; }).join('') + '</select></label></div>' +
            (p.delivery === 'omat_mitat' && S.measureTerms ? '<div class="terms small">' + esc(S.measureTerms) + '</div>' : '') + '</details></div>';
        }).join('') : '<div class="empty">Ei kohteita.</div>') +
        '<div class="sect"><h3>Avoimet tehtävät</h3>' + (c.tasks.length ? c.tasks.map(taskRow).join('') : '<p class="muted small">Ei avoimia tehtäviä.</p>') +
        '<form class="form" id="ctask"><input class="grow" name="title" placeholder="Uusi tehtävä, esim. Soita ' + esc(c.name.split(' ')[0]) + 'lle" aria-label="Tehtävä" required>' +
        (isOwner() ? '<select name="assignee_id" aria-label="Vastuuhenkilö">' + opt(S.users, S.me.id) + '</select>' : '') +
        '<input name="due_date" type="date" aria-label="Päivämäärä" value="' + esc(S.today) + '"><button class="btn p">Lisää</button></form></div>' +
        '<div class="sect"><h3>Historia</h3><form class="form" id="cnote" style="margin:0 0 12px"><input class="grow" name="text" placeholder="Kirjaa muistiinpano, esim. puhelu tai sovittu asia" aria-label="Muistiinpano" required><button class="btn">Tallenna</button></form>' +
        (c.events.length ? '<ul class="hist">' + c.events.map(function (e) { return '<li><div class="d">' + esc(ftime(e.at)) + (e.by ? ' · ' + esc(e.by) : '') + (e.for_customer ? ' · näkyy asiakkaalle' : '') + '</div>' + esc(e.text) + '</li>'; }).join('') + '</ul>' : '<p class="muted small">Ei tapahtumia.</p>') + '</div>' +
        '<details class="more sect"><summary>Käynnit, suosittelut ja muut tiedot</summary>' + (window.NAPV.visits ? window.NAPV.visits.cardBlock(c) : '') +
        '<div class="sect"><h3>Suosittelut</h3><p class="small muted">Suosittelukoodi ' + esc(c.ref_code) + '</p>' + (c.referrals.length ? c.referrals.map(function (r) { return '<div class="small"><a href="#asiakas-' + r.id + '">' + esc(r.name) + '</a> · <span class="pill ' + (r.stage === 6 ? 'good' : '') + '">' + esc(S.stages[r.stage]) + '</span></div>'; }).join('') : '<p class="muted small">Ei vielä suositeltuja asiakkaita.</p>') + '</div></details>' +
        '<div class="actions"><a class="btn" href="#uusi-' + c.id + '">+ Uusi kohde</a><button class="btn p" id="invite">Lähetä Oma kohde -linkki</button><button class="btn" id="editc">Muokkaa yhteystietoja</button>' +
        (isOwner() ? '<button class="btn danger" id="delc">Poista asiakas</button>' : '') + '</div><div id="editbox"></div>';
      bindCard(c);
    }).catch(function (e) { var b = document.getElementById('ccard'); if (b) b.innerHTML = '<div class="empty">' + esc(e.message) + '</div>'; });
  }
  var HOW = [['puhelin', 'Puhelimessa'], ['paikan', 'Paikan päällä'], ['sahkoposti', 'Sähköpostilla'], ['viesti', 'WhatsAppissa tai tekstiviestillä'], ['paperi', 'Allekirjoitti paperisen tarjouksen']];
  function openApprove(c, pid) {
    var w = document.querySelector('[data-apprw="' + pid + '"]'); if (!w) return;
    var p = c.projects.filter(function (x) { return x.id === pid; })[0];
    w.innerHTML = '<form class="apprf"><h3>Tarjouksen hyväksyntä asiakkaan puolesta</h3><div class="fields">' +
      '<label class="fld">Hyväksytty hinta (€, sis. alv) *<input name="value" type="number" min="1" step="1" required value="' + (p.value || '') + '"></label>' +
      '<label class="fld">Miten asiakas hyväksyi *<select name="how" required><option value="">Valitse</option>' + HOW.map(function (h) { return '<option value="' + h[0] + '">' + h[1] + '</option>'; }).join('') + '</select></label>' +
      '<label class="fld wide">Lisätiedot<textarea name="note" rows="2" placeholder="esim. sovittu, että ulko-ovi vaihdetaan malliin X"></textarea></label></div>' +
      (p.delivery === 'omat_mitat' && S.measureTerms ? '<div class="terms small"><b>Asiakas mittaa itse.</b> Kerro asiakkaalle ennen hyväksyntää: ' + esc(S.measureTerms) + '</div>' : '') +
      '<div class="choices">' +
      '<label><input type="checkbox" name="confirm"' + (c.email ? ' checked' : ' disabled') + '><span>Lähetä asiakkaalle vahvistus sähköpostilla' + (c.email ? ' (' + esc(c.email) + ')' : ' (ei sähköpostia)') + '</span></label></div>' +
      '<div class="actions"><button class="btn p">Merkitse hyväksytyksi</button><button type="button" class="btn" data-cancel>Peruuta</button></div></form>';
    var f = w.querySelector('form');
    f.value.focus();
    w.querySelector('[data-cancel]').addEventListener('click', function () { loadCard(c.id); });
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!f.how.value) { toast('Valitse, miten asiakas hyväksyi', true); return; }
      f.querySelector('.btn.p').disabled = true;
      api('projects/' + pid + '/approve', { method: 'POST', body: { value: f.value.value, how: f.how.value, note: f.note.value, confirm: f.confirm.checked } })
        .then(function (np) {
          S.board = S.board.map(function (x) { return x.id === np.id ? Object.assign(x, np) : x; });
          return api('tasks').then(function (t) { S.tasks = t; drawNav('asiakkaat'); });
        }).then(function () { toast('Tarjous merkitty hyväksytyksi'); loadCard(c.id); })
        .catch(function (err) { f.querySelector('.btn.p').disabled = false; fail(err); });
    });
  }
  /* ---------- Kohteen eteneminen: yksi vaihe kerrallaan, seuraava toimenpide aina näkyvissä ---------- */
  function flowBox(p, c) {
    var VV = window.NAPV.visits;
    var vs = (c.visits || []).filter(function (v) { return v.project_id === p.id && v.status !== 'cancelled'; });
    var instType = p.delivery === 'asennus' ? 'asennus' : 'toimitus';
    var mv = vs.filter(function (v) { return v.type === 'mittaus'; })[0];
    var iv = vs.filter(function (v) { return v.type === instType; })[0];
    var dayWord = instType === 'asennus' ? 'Asennuspäivä' : 'Toimituspäivä';
    var when = function (v) { return VV ? VV.when(v) : fdate(v.start_at); };
    var own = p.delivery === 'omat_mitat';
    var a = p.approval, o = p.offer;
    var steps = [
      { t: 'Tarjouspyyntö', done: true, sub: c.email ? 'Asiakas sai kiitosviestin automaattisesti.' : 'Asiakkaalla ei ole sähköpostia – soita.' },
      own ? { t: 'Mitat asiakkaalta', done: p.stage >= 1, sub: p.stage >= 1 ? 'Mitat saatu.' : 'Odotetaan asiakkaan mittoja.',
        act: '<button type="button" class="btn sm p" data-flow="mitat">Mitat saatu</button>' } :
      { t: 'Mittauskäynti', done: !!(mv && mv.confirmed) || (!mv && p.stage >= 1),
        sub: mv ? when(mv) + (mv.installer_id ? ' · ' + uname(mv.installer_id) : '') + (mv.confirmed ? ' · vahvistettu asiakkaalle' : ' · ei vielä vahvistettu asiakkaalle') : (p.stage >= 1 ? 'Ohitettu tai kirjattu tehdyksi ilman käyntiä.' : 'Sovi päivä asiakkaan kanssa ja kirjaa se tähän: asiakas saa vahvistuksen ja muistutuksen.'),
        act: mv ? '<button type="button" class="btn sm p" data-flow="confirm" data-visit="' + mv.id + '">Lähetä vahvistus asiakkaalle</button><a class="btn sm" href="#kaynti-' + mv.id + '">Avaa käynti</a>'
          : '<button type="button" class="btn sm p" data-flow="book" data-type="mittaus">Sovi mittauskäynti</button>' },
      { t: 'Tarjous', done: !!o || p.stage >= 2,
        sub: o ? (o.mode === 'pdf' ? 'PDF-tarjous' : eur(o.sum)) + ' · lähetetty ' + fdate(o.sent_at) + (o.valid_until ? ' · voimassa ' + fdate(o.valid_until) + ' asti' : '') + (o.status === 'declined' ? ' · asiakas ei ole kiinnostunut' : o.viewed_at ? ' · asiakas avasi ' + fdate(o.viewed_at) : ' · ei vielä avattu') : (p.stage >= 2 ? 'Ohitettu: tarjousta ei ole lähetetty CRM:stä.' : 'Tee tarjous laskurilla tai liitä valmis PDF.'),
        act: '<button type="button" class="btn sm p" data-offer="' + p.id + '">Tee tarjous</button>',
        extra: !o ? (!a ? '<button type="button" class="btn sm" data-offer="' + p.id + '">Tee tarjous</button>' : '') : o ? (o.attachments || []).map(function (at, i) { return '<a class="btn sm" target="_blank" rel="noopener" href="' + esc(location.pathname + '?tarjous_liite=' + p.id + '&i=' + i) + '" title="' + esc(at.name) + '">' + (at.kind === 'kuva' ? 'Kuva' : 'Esite') + ((o.attachments || []).length > 1 ? ' ' + (i + 1) : '') + '</a>'; }).join('') + (o.file ? '<a class="btn sm" target="_blank" rel="noopener" href="' + esc(location.pathname + '?tarjous_pdf=' + p.id) + '">Avaa PDF</a>' : '') + (!a ? '<button type="button" class="btn sm" data-offer="' + p.id + '">Lähetä päivitetty tarjous</button>' : '') : '' },
      { t: 'Hyväksyntä', done: !!a || p.stage >= 3,
        sub: a ? 'Hyväksytty ' + fdate(a.at) + ' · ' + (a.how === 'portaali' ? 'asiakas itse tarjoussivulla' : 'asiakkaan puolesta (' + a.how_label + ', ' + a.by_name + ')') + (a.value ? ' · ' + eur(a.value) : '') : (p.stage >= 3 ? 'Ohitettu: hyväksyntää ei ole kirjattu.' : 'Asiakas hyväksyy tarjouksen itse linkistä, tai kirjaat hyväksynnän hänen puolestaan.'),
        act: '<div data-apprw="' + p.id + '"><button type="button" class="btn sm p" data-approve="' + p.id + '">Hyväksy asiakkaan puolesta</button></div>',
        extra: !a ? '<div data-apprw="' + p.id + '"><button type="button" class="btn sm" data-approve="' + p.id + '">Kirjaa hyväksyntä</button></div>' : '' },
      { t: dayWord, done: !!(iv && iv.confirmed) || (!iv && p.stage >= 5),
        sub: iv ? when(iv) + (iv.installer_id ? ' · ' + uname(iv.installer_id) : '') + (iv.confirmed ? ' · varmistettu: asiakas sai vahvistuksen ja sopimusehdot' : ' · alustava, ei vielä varmistettu') : 'Syötä sovittu päivä. Kun se on varmistunut, kuittaa se: asiakas saa vahvistuksen ja sopimusehdot.',
        act: iv ? '<button type="button" class="btn sm p" data-flow="confirm" data-visit="' + iv.id + '" data-terms="1">Kuittaa varmistuneeksi</button><button type="button" class="btn sm" data-flow="edit" data-visit="' + iv.id + '">Muuta päivää</button>'
          : '<button type="button" class="btn sm p" data-flow="book" data-type="' + instType + '">Syötä ' + dayWord.toLowerCase() + '</button>' },
      { t: 'Valmis', done: p.stage >= 6, sub: p.stage >= 6 ? 'Työ on valmis. Lasku lähetetään erikseen.' : 'Kun työ on tehty: asentaja kuittaa luovutuksen puhelimella, tai merkitse valmiiksi tästä.',
        act: '<button type="button" class="btn sm p" data-flow="done">Merkitse valmiiksi</button>' }
    ];
    var cur = -1;
    steps.forEach(function (s, i) { if (cur < 0 && !s.done) cur = i; });
    return '<ol class="flow">' + steps.map(function (s, i) {
      var state = s.done ? 'done' : i === cur ? 'now' : 'todo';
      return '<li class="' + state + '"><span class="dot" aria-hidden="true">' + (s.done ? '✓' : i + 1) + '</span><div><b>' + esc(s.t) + '</b>' +
        (state === 'todo' ? (s.act ? '<button type="button" class="flow-open" data-flowopen aria-expanded="false">Tee tämä vaihe nyt</button><div class="flow-more" hidden><div class="small muted">' + esc(s.sub) + '</div><div class="actions">' + s.act + '</div></div>' : '') : '<div class="small muted">' + esc(s.sub) + '</div>') +
        (state === 'now' && s.act ? '<div class="actions">' + s.act + '</div>' : '') +
        (state === 'done' && s.extra ? '<div class="actions">' + s.extra + '</div>' : '') + '</div></li>';
    }).join('') + '</ol>';
  }
  function bindFlow(c) {
    var VV = window.NAPV.visits;
    // Tulevan vaiheen voi avata ja tehdä heti: aiemmat vaiheet jäävät ohitetuiksi.
    document.querySelectorAll('#ccard [data-flowopen]').forEach(function (b) {
      b.addEventListener('click', function () { var m = b.nextElementSibling, open = m.hidden; m.hidden = !open; b.setAttribute('aria-expanded', open ? 'true' : 'false'); b.textContent = open ? 'Piilota' : 'Tee tämä vaihe nyt'; });
    });
    document.querySelectorAll('#ccard [data-proj]').forEach(function (el) {
      var pid = +el.getAttribute('data-proj');
      var p = c.projects.filter(function (x) { return x.id === pid; })[0];
      el.querySelectorAll('[data-flow]').forEach(function (b) {
        b.addEventListener('click', function () {
          var what = b.getAttribute('data-flow'), vid = +b.getAttribute('data-visit');
          if (what === 'book' && VV) { VV.visitForm({ project_id: pid, type: b.getAttribute('data-type'), back: 'asiakas-' + c.id }); return; }
          if (what === 'edit' && VV) { api('visits/' + vid).then(function (v) { VV.visitForm({ back: 'asiakas-' + c.id }, v); }).catch(fail); return; }
          if (what === 'confirm') {
            var terms = b.getAttribute('data-terms');
            if (!confirm(terms ? 'Kuitataanko päivä varmistuneeksi? Asiakkaalle lähtee vahvistus ja sopimusehdot sähköpostilla.' : 'Lähetetäänkö asiakkaalle vahvistus mittauskäynnistä?')) return;
            b.disabled = true;
            api('visits/' + vid + '/confirm', { method: 'POST' }).then(function (v) {
              toast(v.mail_sent ? 'Vahvistettu ja lähetetty asiakkaalle' : 'Vahvistettu (asiakkaalla ei sähköpostia – kerro itse)');
              return window.NAPV.reloadBoard();
            }).then(function () { loadCard(c.id); }).catch(function (err) { b.disabled = false; fail(err); });
            return;
          }
          var stage = what === 'mitat' ? 1 : what === 'done' ? 6 : null;
          if (stage === null) return;
          if (what === 'done' && !confirm('Merkitäänkö kohde valmiiksi?')) return;
          b.disabled = true;
          api('projects/' + pid, { method: 'POST', body: { stage: stage } }).then(function (np) {
            S.board = S.board.map(function (x) { return x.id === np.id ? Object.assign(x, np) : x; });
            toast(what === 'done' ? 'Kohde valmis' : 'Mitat kirjattu');
            return api('tasks').then(function (t) { S.tasks = t; drawNav('asiakkaat'); });
          }).then(function () { loadCard(c.id); }).catch(function (err) { b.disabled = false; fail(err); });
        });
      });
    });
  }
  function addDays(n) { var d = new Date(S.today + 'T12:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); }
  function openOffer(c, pid) {
    var w = document.querySelector('[data-offw="' + pid + '"]'); if (!w) return;
    w.scrollIntoView({ block: 'nearest' });
    var p = c.projects.filter(function (x) { return x.id === pid; })[0], o = p.offer || {};
    var calcFirst = !!window.NAPLaskuri && (!o.mode || !!o.calc);
    var pdfFirst = !calcFirst && (o.mode ? o.mode === 'pdf' : true);
    w.innerHTML = '<form class="apprf" enctype="multipart/form-data"><h3>' + (p.offer ? 'Päivitetty tarjous' : 'Tarjous asiakkaalle') + '</h3>' +
      '<p class="small muted" style="margin:0">Asiakas avaa tarjouksen sähköpostin linkistä ja voi hyväksyä sen tai kysyä tarkennusta.</p>' +
      '<div class="choices">' + (window.NAPLaskuri ? '<label><input type="radio" name="mode" value="calc"' + (calcFirst ? ' checked' : '') + '><span><b>Laskuri</b> – laske tarjous riveittäin, CRM tekee siitä PDF:n ja lähettää sen</span></label>' : '') +
      '<label><input type="radio" name="mode" value="pdf"' + (pdfFirst ? ' checked' : '') + '><span><b>Valmis PDF-tarjous</b> – erittely, hinta ja voimassaolo ovat PDF:ssä</span></label>' +
      '<label><input type="radio" name="mode" value="fields"' + (pdfFirst || calcFirst ? '' : ' checked') + '><span><b>Täytä tiedot</b> – hinta, työn osuus ja sisältö näkyvät asiakkaalle sivulla (PDF valinnainen)</span></label></div><div data-calc hidden></div><div class="fields">' +
      '<label class="fld wide" data-pdffile>Tarjous PDF:nä (Skaalan tarjoustyökalusta)<span class="muted small" data-pdfhint>' + (o.file ? ' – jätä tyhjäksi, niin edellinen PDF säilyy' : '') + '</span><input name="pdf" type="file" accept="application/pdf,.pdf"></label>' +
      '<label class="fld" data-pdfonly>Hinta myyntiputkeen (€, valinnainen)<input name="sum_pdf" type="number" min="0" step="1" value="' + (o.sum || p.value || '') + '"><span class="muted small" style="font-weight:400">Ei näy asiakkaalle.</span></label>' +
      '<label class="fld" data-fieldsonly>Hinta yhteensä (€, sis. alv) *<input name="sum" type="number" min="1" step="1" value="' + (o.sum || p.value || '') + '"></label>' +
      '<label class="fld" data-fieldsonly>Josta työn osuus (€)<input name="labor" type="number" min="0" step="1" value="' + (o.labor || '') + '"></label>' +
      '<label class="fld wide" data-fieldsonly>Sisältö (näkyy asiakkaalle)<textarea name="content" rows="4" placeholder="esim. 9 kpl Skaala Alfa -ikkunaa, ulko-ovi Aika F1, asennus ja vanhojen poisvienti">' + esc(o.content || p.title || '') + '</textarea></label>' +
      '<label class="fld wide" data-fieldsonly>Lisätiedot asiakkaalle<textarea name="notes" rows="2" placeholder="esim. toimitusaika noin 6–8 viikkoa tilauksesta">' + esc(o.notes || '') + '</textarea></label></div>' +
      '<div class="fld attpick"><span>Liitteet: tuote-esitteet ja kuvat (valinnainen)</span>' +
      '<div class="actions" style="margin:0"><button type="button" class="btn sm" data-attadd>+ Lisää liitteitä</button><input type="file" data-attinput multiple hidden accept="application/pdf,image/jpeg,image/png,image/webp"></div>' +
      '<ul class="attlist" data-attlist></ul>' +
      '<span class="muted small" style="font-weight:400">PDF, JPG, PNG tai WebP. Voit lisätä tiedostoja yksi kerrallaan tai useita kerralla. Enintään 10 liitettä, 15 Mt kukin. Asiakas näkee ne tarjoussivulla tarjouksen alla.</span></div>' +
      ((o.attachments || []).length ? '<div class="choices"><span class="small muted">Aiemmat liitteet säilyvät, ellet poista niitä:</span>' + o.attachments.map(function (a, i) { return '<label><input type="checkbox" name="remove_attachment[]" value="' + i + '"><span>Poista ' + (a.kind === 'kuva' ? 'kuva' : 'esite') + ': ' + esc(a.name) + '</span></label>'; }).join('') + '</div>' : '') +
      '<p class="small muted" style="margin:0">Tarjous on voimassa ' + S.offerDays + ' päivää lähetyksestä (' + esc(fdate(addDays(S.offerDays))) + ' asti). Asiakas avaa sen suoraan sähköpostin linkistä ilman kirjautumista.</p>' +
      '<div class="choices"><label><input type="checkbox" name="notify"' + (c.email ? ' checked' : ' disabled') + '><span>Lähetä asiakkaalle sähköposti, jossa linkki tarjoukseen' + (c.email ? ' (' + esc(c.email) + ')' : ' (ei sähköpostia: kerro asiakkaalle itse)') + '</span></label></div>' +
      '<p class="small muted" style="margin:0" data-calchint hidden>Haluatko lähettää tarjouksen omasta sähköpostistasi? Ota yllä oleva rasti pois, paina Lataa PDF ja liitä tiedosto viestiisi. Kun painat sen jälkeen Lähetä tarjous, tarjous kirjautuu CRM:ään ja asiakkaan Oma kohde -sivulle ilman CRM:n sähköpostia.</p>' +
      '<div class="actions"><button class="btn p">Lähetä tarjous</button><button type="button" class="btn" data-preview hidden>Esikatsele PDF</button><button type="button" class="btn" data-download hidden>Lataa PDF</button><button type="button" class="btn" data-cancel>Peruuta</button></div></form>';
    var f = w.querySelector('form'), L = null, validUntil = (function (d) { var a = d.split('-'); return (+a[2]) + '.' + (+a[1]) + '.' + a[0]; })(addDays(S.offerDays));
    function onMode() {
      var pdf = f.mode.value === 'pdf', calc = f.mode.value === 'calc';
      f.querySelectorAll('[data-fieldsonly]').forEach(function (el) { el.hidden = pdf || calc; });
      f.querySelectorAll('[data-pdfonly]').forEach(function (el) { el.hidden = !pdf; });
      f.querySelector('[data-pdffile]').hidden = calc;
      f.querySelector('[data-calc]').hidden = !calc;
      f.querySelector('[data-preview]').hidden = !calc;
      f.querySelector('[data-download]').hidden = !calc;
      f.querySelector('[data-calchint]').hidden = !calc;
      f.sum.required = !pdf && !calc;
      f.pdf.required = pdf && !o.file;
      if (calc && !L) {
        L = window.NAPLaskuri.mount(f.querySelector('[data-calc]'), {
          state: o.calc || null, jspdf: C.jspdf, laskija: S.me.name, asiakas: c.name, template: S.calcTemplate, onSaveTemplate: isOwner() ? saveCalcTemplate : null,
          kohde: p.address || [c.address, c.city].filter(Boolean).join(', '),
          numero: new Date().getFullYear() + '-' + ('000' + p.id).slice(-4) + (o.version ? '-' + (o.version + 1) : ''),
          newNumber: !!o.version   // päivitetty tarjous saa uuden numeron
        });
      }
    }
    f.querySelector('[data-download]').addEventListener('click', function () {
      if (!L || !L.compute().items.length) { toast('Valitse laskurista vähintään yksi rivi.', true); return; }
      var b = this; b.disabled = true;
      L.pdf({ validUntil: validUntil }).then(function (blob) { savePdf(blob, L.fileName()); b.disabled = false; toast('PDF ladattu'); })
        .catch(function (err) { b.disabled = false; fail(err); });
    });
    f.querySelector('[data-preview]').addEventListener('click', function () {
      if (!L || !L.compute().items.length) { toast('Valitse laskurista vähintään yksi rivi.', true); return; }
      var win = window.open('', '_blank');
      L.pdf({ validUntil: validUntil }).then(function (blob) { var u = URL.createObjectURL(blob); if (win) { win.location = u; } else { savePdf(blob, L.fileName()); } })
        .catch(function (err) { if (win) win.close(); fail(err); });
    });
    // Liitteet kerätään omaan listaan: selaimen tiedostovalitsin korvaisi aiemman valinnan joka kerta.
    var picked = [], attInput = f.querySelector('[data-attinput]'), attList = f.querySelector('[data-attlist]');
    var keptCount = (o.attachments || []).length;
    function drawPicked() {
      attList.innerHTML = picked.map(function (x, i) {
        return '<li><span>' + esc(x.name) + ' <span class="muted">(' + (x.size > 1048576 ? (x.size / 1048576).toFixed(1).replace('.', ',') + ' Mt' : Math.max(1, Math.round(x.size / 1024)) + ' kt') + ')</span></span><button type="button" class="btn sm" data-attdel="' + i + '" aria-label="Poista liite ' + esc(x.name) + '">Poista</button></li>';
      }).join('');
    }
    f.querySelector('[data-attadd]').addEventListener('click', function () { attInput.click(); });
    attInput.addEventListener('change', function () {
      var skipped = [];
      Array.prototype.forEach.call(attInput.files, function (x) {
        var dup = picked.some(function (y) { return y.name === x.name && y.size === x.size; });
        var removing = f.querySelectorAll('[name="remove_attachment[]"]:checked').length;
        if (dup) return;
        if (x.size > 15 * 1048576) { skipped.push(x.name + ' on yli 15 Mt'); return; }
        if (!/\.(pdf|jpe?g|png|webp)$/i.test(x.name)) { skipped.push(x.name + ' ei ole PDF tai kuva'); return; }
        if (keptCount - removing + picked.length >= 10) { skipped.push(x.name + ': enintään 10 liitettä'); return; }
        picked.push(x);
      });
      attInput.value = ''; // sama tiedosto voidaan valita uudelleen poiston jälkeen
      drawPicked();
      if (skipped.length) toast('Ei lisätty: ' + skipped.join('; '), true);
    });
    attList.addEventListener('click', function (e) {
      var b = e.target.closest('[data-attdel]'); if (!b) return;
      picked.splice(+b.getAttribute('data-attdel'), 1); drawPicked();
    });
    f.querySelectorAll('[name=mode]').forEach(function (r) { r.addEventListener('change', onMode); });
    onMode();
    w.querySelector('[data-cancel]').addEventListener('click', function () { loadCard(c.id); });
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var fd = new FormData(f); fd.set('notify', f.notify.checked ? '1' : '');
      picked.forEach(function (file) { fd.append('liitteet[]', file, file.name); });
      if (f.mode.value === 'pdf') fd.set('sum', f.sum_pdf.value || '0');
      fd.delete('sum_pdf');
      var ready = Promise.resolve(fd);
      if (f.mode.value === 'calc') {
        var comp = L.compute();
        if (!comp.items.length || !comp.gross) { toast('Valitse laskurista vähintään yksi rivi ja anna hinta.', true); return; }
        // Laskurin tarjous lähtee PDF-tarjouksena: PDF tehdään selaimessa ja laskelma tallennetaan muokkausta varten.
        ready = L.pdf({ validUntil: validUntil }).then(function (blob) {
          var d = new FormData();
          d.set('mode', 'pdf'); d.set('notify', f.notify.checked ? '1' : '');
          d.set('sum', String(Math.round(comp.gross * 100) / 100));
          d.set('calc', JSON.stringify(L.getState()));
          d.set('pdf', blob, L.fileName());
          picked.forEach(function (file) { d.append('liitteet[]', file, file.name); });
          f.querySelectorAll('[name="remove_attachment[]"]:checked').forEach(function (b) { d.append('remove_attachment[]', b.value); });
          return d;
        });
      }
      f.querySelector('.btn.p').disabled = true;
      ready.then(function (body) { return api('projects/' + pid + '/offer', { method: 'POST', form: body }); }).then(function (np) {
        S.board = S.board.map(function (x) { return x.id === np.id ? Object.assign(x, np) : x; });
        return api('tasks').then(function (t) { S.tasks = t; drawNav('asiakkaat'); });
      }).then(function () { toast('Tarjous lähetetty'); loadCard(c.id); })
        .catch(function (err) { f.querySelector('.btn.p').disabled = false; fail(err); });
    });
  }
  function bindCard(c) {
    var box = document.getElementById('ccard');
    if (window.NAPV.visits) window.NAPV.visits.bindCard(c);
    bindFlow(c);
    box.querySelectorAll('[data-offer]').forEach(function (b) { b.addEventListener('click', function () { openOffer(c, +b.getAttribute('data-offer')); }); });
    if (S.openOffer) { var of = S.openOffer; S.openOffer = null; openOffer(c, of); var ow = document.querySelector('[data-offw="' + of + '"]'); if (ow) ow.scrollIntoView({ block: 'center' }); }
    box.querySelectorAll('[data-approve]').forEach(function (b) { b.addEventListener('click', function () { openApprove(c, +b.getAttribute('data-approve')); }); });
    if (S.openApprove) { var oa = S.openApprove; S.openApprove = null; openApprove(c, oa); var w = document.querySelector('[data-apprw="' + oa + '"]'); if (w) w.scrollIntoView({ block: 'center' }); }
    var ow = document.getElementById('owner');
    if (ow) ow.addEventListener('change', function () { api('customers/' + c.id, { method: 'POST', body: { owner_id: +ow.value } }).then(function () { toast('Vastuumyyjä vaihdettu'); }).catch(fail); });
    box.querySelectorAll('[data-proj]').forEach(function (el) {
      var pid = +el.getAttribute('data-proj');
      el.querySelectorAll('[data-f]').forEach(function (f) {
        f.addEventListener('change', function () {
          var proj = c.projects.filter(function (x) { return x.id === pid; })[0];
          if (f.getAttribute('data-f') === 'stage' && +f.value === 2 && proj.stage < 2 && !proj.offer) {
            f.value = proj.stage; openOffer(c, pid); toast('Lisää tarjouksen tiedot, niin asiakas näkee sen'); return;
          }
          if (f.getAttribute('data-f') === 'stage' && +f.value >= 3 && proj.stage < 3 && !proj.approval) {
            f.value = proj.stage; openApprove(c, pid); toast('Kirjaa ensin asiakkaan hyväksyntä'); return;
          }
          var body = {}; body[f.getAttribute('data-f')] = f.value;
          api('projects/' + pid, { method: 'POST', body: body }).then(function (np) {
            S.board = S.board.map(function (x) { return x.id === np.id ? Object.assign(x, np) : x; });
            toast(f.getAttribute('data-f') === 'stage' ? 'Vaihe: ' + S.stages[np.stage] : 'Tallennettu'); loadCard(c.id);
          }).catch(fail);
        });
      });
    });
    document.getElementById('ctask').addEventListener('submit', function (e) {
      e.preventDefault(); var f = e.target;
      api('tasks', { method: 'POST', body: { title: f.title.value, assignee_id: f.assignee_id ? +f.assignee_id.value : S.me.id, due_date: f.due_date.value, customer_id: c.id, project_id: c.projects[0] ? c.projects[0].id : null } })
        .then(function (t) { S.tasks.push(t); toast('Tehtävä lisätty'); drawNav('asiakkaat'); loadCard(c.id); }).catch(fail);
    });
    document.getElementById('cnote').addEventListener('submit', function (e) {
      e.preventDefault(); api('customers/' + c.id + '/note', { method: 'POST', body: { text: e.target.text.value } }).then(function () { toast('Muistiinpano tallennettu'); loadCard(c.id); }).catch(fail);
    });
    document.getElementById('invite').addEventListener('click', function (e) {
      e.target.disabled = true;
      api('customers/' + c.id + '/invite', { method: 'POST' }).then(function () { toast('Kirjautumislinkki lähetetty: ' + c.email); loadCard(c.id); }).catch(function (err) { e.target.disabled = false; fail(err); });
    });
    var dc = document.getElementById('delc');
    if (dc) dc.addEventListener('click', function () {
      if (!confirm('Poistetaanko ' + c.name + ' pysyvästi kaikkine tietoineen? Käytä tätä roskapostille ja testeille. Tätä ei voi perua.')) return;
      deleteCustomers([c.id]);
    });
    document.getElementById('editc').addEventListener('click', function () {
      document.getElementById('editbox').innerHTML = '<form class="card" id="cedit" style="margin-top:12px"><div class="fields">' +
        [['name', 'Nimi'], ['email', 'Sähköposti'], ['phone', 'Puhelin'], ['address', 'Katuosoite'], ['city', 'Paikkakunta'], ['source', 'Lähde']].map(function (f) {
          return '<label class="fld">' + f[1] + '<input name="' + f[0] + '" value="' + esc(c[f[0]] || '') + '"' + (f[0] === 'email' ? ' type="email"' : '') + '></label>';
        }).join('') + '</div><div class="actions"><button class="btn p">Tallenna</button></div></form>';
      document.getElementById('cedit').addEventListener('submit', function (e) {
        e.preventDefault(); var f = e.target, body = {};
        ['name', 'email', 'phone', 'address', 'city', 'source'].forEach(function (k) { body[k] = f[k].value; });
        api('customers/' + c.id, { method: 'POST', body: body }).then(function () { toast('Tiedot tallennettu'); loadCustomers().then(function () { viewCustomers(c.id); }); }).catch(fail);
      });
    });
  }

  function viewTasks() {
    var l = S.tasks.slice();
    if (S.taskFilter === 'omat') l = l.filter(function (t) { return t.assignee_id === S.me.id; });
    if (S.taskFilter === 'myohassa') l = l.filter(function (t) { return !t.done && t.due_date && t.due_date < S.today; });
    l.sort(function (a, b) { return (a.done - b.done) || String(a.due_date || '9999').localeCompare(String(b.due_date || '9999')); });
    main.innerHTML = head('Tehtävät', 'Soitot, hakemukset, lahjat ja muut muistettavat') +
      '<div class="card"><h2>Tehtävät <span class="r"><span class="seg" id="tf">' + [['omat', 'Omat'], ['kaikki', 'Kaikki'], ['myohassa', 'Myöhässä']].map(function (f) { return '<button type="button" data-f="' + f[0] + '" class="' + (S.taskFilter === f[0] ? 'on' : '') + '">' + f[1] + '</button>'; }).join('') + '</span></span></h2>' +
      (l.length ? l.map(taskRow).join('') : '<div class="empty">Ei tehtäviä tällä rajauksella.</div>') +
      '<form class="form" id="ntask"><input class="grow" name="title" placeholder="Uusi tehtävä" aria-label="Tehtävä" required>' + (isOwner() ? '<select name="assignee_id" aria-label="Vastuuhenkilö">' + opt(S.users, S.me.id) + '</select>' : '') +
      '<input name="due_date" type="date" value="' + esc(S.today) + '" aria-label="Päivämäärä"><button class="btn p">Lisää</button></form></div>';
    document.getElementById('tf').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) { S.taskFilter = b.getAttribute('data-f'); viewTasks(); } });
    document.getElementById('ntask').addEventListener('submit', function (e) {
      e.preventDefault(); var f = e.target;
      api('tasks', { method: 'POST', body: { title: f.title.value, assignee_id: f.assignee_id ? +f.assignee_id.value : S.me.id, due_date: f.due_date.value } })
        .then(function (t) { S.tasks.push(t); toast('Tehtävä lisätty'); render(); }).catch(fail);
    });
  }

  /* ---------- Viestin jäsennys: puhelin, sähköposti, osoite, nimi ja tuotteet liitetystä viestistä ---------- */
  var CITIES = ['Turku', 'Masku', 'Raisio', 'Naantali', 'Kaarina', 'Lieto', 'Rusko', 'Nousiainen', 'Mynämäki', 'Taivassalo', 'Kustavi', 'Uusikaupunki',
    'Laitila', 'Vehmaa', 'Pyhäranta', 'Salo', 'Paimio', 'Sauvo', 'Parainen', 'Aura', 'Pöytyä', 'Marttila', 'Koski Tl', 'Loimaa', 'Oripää', 'Somero',
    'Rauma', 'Eura', 'Säkylä', 'Pori', 'Kemiönsaari', 'Tampere', 'Helsinki', 'Espoo', 'Vantaa', 'Hämeenlinna', 'Forssa'];
  var CITY_FORMS = { Turussa: 'Turku', Turusta: 'Turku', Turkuun: 'Turku', Liedossa: 'Lieto', Liedosta: 'Lieto', 'Mynämäellä': 'Mynämäki', 'Mynämäeltä': 'Mynämäki',
    Uudessakaupungissa: 'Uusikaupunki', Tampereella: 'Tampere', Tampereelta: 'Tampere', Helsingissä: 'Helsinki', Helsingistä: 'Helsinki', Kemiönsaarella: 'Kemiönsaari',
    Pöytyällä: 'Pöytyä', Marttilassa: 'Marttila', Somerolla: 'Somero', Kaarinassa: 'Kaarina', Paraisilla: 'Parainen', Paraisten: 'Parainen' };
  var STREET = '(?:tie|katu|kuja|polku|väylä|ranta|kaari|rinne|mäki|puisto|tanhua|kaarre|raitti|aukio|piha|kulma|linja|niitty|vainio|pelto|ahde|tori|kallio|laakso|lenkki|reitti|haka|nummi|kumpu|kangas|kylä|tanhuantie|gatan|vägen|stigen)';
  function parseMessage(raw) {
    var out = {}, text = String(raw || '').replace(/\r/g, '').trim();
    if (!text) return out;
    // WhatsAppin kopioimat viestit: "[17.10.2026 14.32] Nimi: viesti" tai vienti "17.10.2026 klo 14.32 - Nimi: viesti"
    var wa = /^\s*(?:\[[^\]]{6,30}\]|\d{1,2}[./]\d{1,2}[./]\d{2,4},?\s+(?:klo\s+)?\d{1,2}[.:]\d{2}(?:[.:]\d{2})?\s+-)\s*([^:\n]{2,40}):\s?/;
    var lines = text.split('\n').map(function (l) {
      var m = wa.exec(l);
      if (m) { if (!out.name && !/^\+?\d[\d\s-]+$/.test(m[1])) out.name = m[1].trim(); out.whatsapp = true; return l.slice(m[0].length); }
      return l;
    });
    text = lines.join('\n').trim();
    out.message = text;
    var em = /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/.exec(text);
    if (em) out.email = em[0].toLowerCase();
    var ph = /(?:\+358|00358|(?:^|[^\d])0)[\s-]?\(?\d{1,3}\)?(?:[\s-]?\d){5,8}(?!\d)/.exec(text);
    if (ph) out.phone = ph[0].replace(/^[^\d+]+/, '').replace(/\s{2,}/g, ' ').trim();
    var st = new RegExp('([A-ZÅÄÖ][a-zåäöA-ZÅÄÖ-]*' + STREET + ')\\s+(\\d+(?:\\s?[A-Za-z]{1,2})?(?:\\s?\\d+)?(?:-\\d+)?)\\b').exec(text) ||
      new RegExp('([A-ZÅÄÖ][a-zåäö-]+\\s(?:' + STREET.slice(3, -1) + '))\\s+(\\d+[A-Za-z]?)\\b').exec(text);
    if (st) out.address = (st[1] + ' ' + st[2]).trim();
    var pc = /\b\d{5}\s+([A-ZÅÄÖ][a-zåäö-]+)/.exec(text);
    if (pc) out.city = pc[1];
    if (!out.city && st) { var after = /^,?\s*([A-ZÅÄÖ][a-zåäö-]+)/.exec(text.slice(st.index + st[0].length)); if (after && /^,/.test(text.slice(st.index + st[0].length).trim())) out.city = after[1]; }
    if (!out.city) Object.keys(CITY_FORMS).some(function (f) { if (new RegExp('(^|[^\\wåäö])' + f + '(?![\\wåäö])').test(text)) { out.city = CITY_FORMS[f]; return true; } return false; });
    if (!out.city) CITIES.some(function (c) { if (new RegExp('(^|[^\\wåäö])' + c + '(ssa|ssä|sta|stä|lla|llä|lta|ltä|an|en|in|un|ön|än)?(?![\\wåäö])', 'i').test(text)) { out.city = c; return true; } return false; });
    if (!out.name) {
      var sig = /(?:[Tt]erveisin|[Tt]erv\.|\b[Tt]\.|[Yy]st\.\s*terv\.?)\s*,?\s*\n?\s*([A-ZÅÄÖ][a-zåäö-]+(?:\s[A-ZÅÄÖ][a-zåäö-]+)?)/.exec(text) ||
        /(?:[Oo]len|[Nn]imeni on|[Tt]äällä)\s+([A-ZÅÄÖ][a-zåäö-]+(?:\s[A-ZÅÄÖ][a-zåäö-]+)?)/.exec(text);
      if (sig) out.name = sig[1];
    }
    var prod = [], w = /(\d+)\s*(?:kpl\s*|kappaletta\s*)?(?:uut\w*\s*)?ikkun/i.exec(text);
    if (w) prod.push(w[1] + ' ikkunaa'); else if (/ikkun/i.test(text)) prod.push('ikkunat');
    if (/ulko-?ov/i.test(text)) prod.push('ulko-ovi');
    if (/parveke-?ov/i.test(text)) prod.push('parvekeovi');
    if (/terassi-?ov|terassin ov/i.test(text)) prod.push('terassiovi');
    if (/autotalli/i.test(text)) prod.push('autotallin ovi');
    if (!prod.length && /\bov(i|ia|et|en)\b/i.test(text)) prod.push('ovet');
    if (prod.length) out.title = prod.join(', ').replace(/, ([^,]*)$/, ' ja $1');
    if (/mittaa[a-zä]* (ne )?itse|omat mitat|itse mitat|mitat itse|olen mitannut|mitannut itse/i.test(text)) out.delivery = 'omat_mitat';
    else if (/ilman asennusta|asennan itse|asennamme itse|asennus itse|pelkät (ikkunat|ovet|tuotteet)/i.test(text)) out.delivery = 'ilman_asennusta';
    return out;
  }
  function digits(s) { return String(s || '').replace(/\D/g, '').replace(/^358/, '0').slice(-9); }
  function findExisting(p) {
    return S.customers.filter(function (c) {
      return (p.email && c.email && c.email.toLowerCase() === p.email) || (p.phone && c.phone && digits(c.phone).length >= 7 && digits(c.phone) === digits(p.phone));
    })[0];
  }


  /* ---------- Saapuneet (myynti@ ja info@) ---------- */
  S.ib = { cat: '', onlyNew: false, q: '' };
  function inboxNewCount(counts, hidden) {
    var n = 0; Object.keys(counts || {}).forEach(function (k) { if ((hidden || []).indexOf(k) < 0) n += counts[k].new; }); return n;
  }
  function loadInbox() {
    var qs = ['cat=' + encodeURIComponent(S.ib.cat), S.ib.onlyNew ? 'status=new' : '', S.ib.q ? 'q=' + encodeURIComponent(S.ib.q) : ''].filter(Boolean).join('&');
    return api('inbox?' + qs).then(function (r) { S.inbox = r; S.inboxNew = inboxNewCount(r.counts, r.hidden); drawNav('saapuneet'); return r; });
  }
  function ibTime(dt) { return String(dt).slice(0, 10) === S.today ? 'klo ' + String(dt).slice(11, 16).replace(':', '.') : fdate(dt); }
  function viewInbox(id) {
    if (!S.inbox) { main.innerHTML = head('Saapuneet', 'Ladataan…'); loadInbox().then(function () { viewInbox(id); }).catch(fail); return; }
    var r = S.inbox, cats = r.categories, cnt = r.counts || {};
    var chip = function (k, label) {
      var c = k ? (cnt[k] || { new: 0, total: 0 }) : null, n = k ? c.new : inboxNewCount(cnt, r.hidden);
      return '<button class="ibchip' + (S.ib.cat === k ? ' on' : '') + '" data-cat="' + k + '">' + esc(label) + (n ? ' <b>' + n + '</b>' : (k && c.total ? ' <span>' + c.total + '</span>' : '')) + '</button>';
    };
    var shown = Object.keys(cats).filter(function (k) { return r.hidden.indexOf(k) < 0; });
    if (!id && r.items[0] && window.innerWidth > 860) id = r.items[0].id;
    main.innerHTML = head('Saapuneet', 'myynti@ ja info@ – viestit tunnistettuina', '<button class="btn" id="ibfetch">Hae uudet</button>') +
      (!r.ready ? '<div class="card" style="margin-bottom:14px"><b>Saapuneet ei ole vielä käytössä.</b> <span class="muted">Asetukset → Asiakasportaali → Saapuneet: puuttuu ' + esc((r.missing || []).join(', ')) + '. Täytä ja paina Tallenna muutokset.</span>' + (C.admin ? ' <a href="' + esc(C.admin) + '">Avaa asetukset</a>' : '') + '</div>' : '') +
      (r.status && !r.status.ok ? '<div class="card" style="margin-bottom:14px;border-color:var(--crit)"><b style="color:var(--crit)">Viimeisin haku epäonnistui:</b> ' + esc(r.status.msg) + '</div>' : '') +
      '<div class="ibchips">' + chip('', 'Kaikki') + shown.map(function (k) { return chip(k, cats[k]); }).join('') +
      '<span class="ibsep">Piilotetut:</span>' + r.hidden.map(function (k) { return chip(k, cats[k]); }).join('') + '</div>' +
      '<div class="cust"><div class="card"><div class="search"><input id="ibq" type="search" placeholder="Hae lähettäjällä tai sisällöllä" aria-label="Hae viestejä" value="' + esc(S.ib.q) + '">' +
      '<label class="ibnew"><input type="checkbox" id="ibonly"' + (S.ib.onlyNew ? ' checked' : '') + '> Vain käsittelemättömät</label></div>' +
      (r.items.length ? '<div class="selbar"><label><input type="checkbox" id="iball"> Valitse kaikki</label><button type="button" class="btn sm" id="ibspam" hidden>Roskapostiin</button><button type="button" class="btn sm danger" id="ibdel" hidden>Poista</button>' +
        (S.ib.cat === 'roskaposti' ? '<button type="button" class="btn sm danger" id="ibempty">Tyhjennä roskaposti</button>' : '') + '</div>' : '') +
      '<div class="clist iblist">' + (r.items.length ? r.items.map(function (m) {
        return '<div class="selrow"><input type="checkbox" data-ibsel="' + m.id + '" aria-label="Valitse viesti"><a href="#saapunut-' + m.id + '" class="' + (m.id === id ? 'on' : '') + (m.status === 'new' ? ' unread' : '') + '"><span><span class="ibrow"><b>' + esc(m.from_name || m.from_email) + '</b><span class="small muted">' + esc(ibTime(m.received_at)) + '</span></span>' +
          '<span class="ibsubj">' + (m.files ? '📎 ' : '') + esc(m.subject) + '</span><span class="small muted ibsnip">' + esc(m.snippet) + '</span>' +
          '<span class="ibrow"><span class="pill ' + ibPill(m.category) + '">' + esc(cats[m.category]) + '</span><span class="small muted">' + esc(m.customer || m.mailbox) + '</span></span></span></a></div>';
      }).join('') : '<div class="empty">Ei viestejä tässä näkymässä.</div>') + '</div></div>' +
      '<div class="card" id="ibcard">' + (id ? '<p class="muted">Ladataan…</p>' : '<div class="empty">Valitse viesti listasta.</div>') + '</div></div>';
    main.querySelectorAll('[data-cat]').forEach(function (b) { b.addEventListener('click', function () { S.ib.cat = b.getAttribute('data-cat'); loadInbox().then(function () { viewInbox(); }).catch(fail); }); });
    document.getElementById('ibonly').addEventListener('change', function (e) { S.ib.onlyNew = e.target.checked; loadInbox().then(function () { viewInbox(); }).catch(fail); });
    var q = document.getElementById('ibq'), t;
    q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { S.ib.q = q.value.trim(); loadInbox().then(function () { viewInbox(); var n = document.getElementById('ibq'); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }); }, 300); });
    document.getElementById('ibfetch').addEventListener('click', function (e) {
      e.target.disabled = true; e.target.textContent = 'Haetaan…';
      api('inbox/fetch', { method: 'POST' }).then(function (x) { toast(x.haettu ? 'Uusia viestejä: ' + x.haettu : 'Ei uusia viestejä'); return loadInbox(); })
        .then(function () { viewInbox(route().id); }).catch(function (err) { fail(err); loadInbox().then(function () { viewInbox(route().id); }); });
    });
    var ibBulk = function (action, ids, msg) {
      return api('inbox/bulk', { method: 'POST', body: { action: action, ids: ids || [] } }).then(function (x) { toast(msg + ': ' + (x.poistettu != null ? x.poistettu : x.merkitty)); return loadInbox(); })
        .then(function () { location.hash = 'saapuneet'; viewInbox(); }).catch(fail);
    };
    bindSelection(main, '[data-ibsel]', 'iball', 'ibdel', function (ids) { if (confirm('Poistetaanko ' + ids.length + ' viestiä pysyvästi?')) ibBulk('delete', ids, 'Poistettu'); });
    bindSelection(main, '[data-ibsel]', null, 'ibspam', function (ids) { ibBulk('spam', ids, 'Siirretty roskapostiin'); }, 'Roskapostiin');
    var em = document.getElementById('ibempty');
    if (em) em.addEventListener('click', function () { if (confirm('Poistetaanko kaikki roskapostiviestit pysyvästi?')) ibBulk('empty_spam', [], 'Poistettu'); });
    if (id) loadInboxItem(id);
  }
  function ibPill(cat) { return cat === 'reklamaatio' ? 'crit' : cat === 'tarjouspyynto' ? 'gold' : cat === 'asiakas' ? 'good' : ''; }
  function loadInboxItem(id) {
    api('inbox/' + id).then(function (m) {
      var box = document.getElementById('ibcard'); if (!box) return;
      var cats = S.inbox.categories;
      if (m.status === 'new' && m.category !== 'muu') { /* avaus ei kuittaa: käsittely merkitään itse */ }
      box.innerHTML = '<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:flex-start"><h2 style="margin:0">' + esc(m.subject) + '</h2>' +
        '<span class="pill ' + ibPill(m.category) + '">' + esc(cats[m.category]) + '</span></div>' +
        '<dl class="kv" style="margin-top:10px"><dt>Lähettäjä</dt><dd>' + esc(m.from_name) + ' &lt;' + esc(m.from_email) + '&gt;</dd><dt>Saapui</dt><dd>' + esc(ftime(m.received_at)) + (m.mailbox ? ' · ' + esc(m.mailbox) : '') + '</dd>' +
        '<dt>Tunnistus</dt><dd class="small muted">' + esc(m.reason) + '</dd>' +
        '<dt>Asiakas</dt><dd>' + (m.customer_id ? '<a href="#asiakas-' + m.customer_id + '">' + esc(m.customer) + '</a>' : '<select id="iblink" aria-label="Liitä asiakkaaseen"><option value="">Ei liitetty – valitse asiakas</option>' + S.customers.map(function (c) { return '<option value="' + c.id + '">' + esc(c.name) + '</option>'; }).join('') + '</select>') + '</dd></dl>' +
        '<div class="actions" style="margin:10px 0">' +
        (!m.customer_id ? '<button class="btn p" id="iblead">Luo tarjouspyyntö</button>' : '<button class="btn p" id="iboffer">Tee tarjous laskurilla</button>') +
        '<a class="btn" href="mailto:' + esc(m.from_email) + '?subject=' + encodeURIComponent('Re: ' + m.subject) + '">Vastaa</a>' +
        '<button class="btn" id="ibdone">' + (m.status === 'new' ? '✓ Merkitse käsitellyksi' : 'Palauta käsittelemättömäksi') + '</button>' +
        (m.category !== 'roskaposti' ? '<button class="btn" id="ibspam1">Roskapostia</button>' : '') + '<button class="btn danger" id="ibdel1">Poista</button>' +
        '<select id="ibcat" aria-label="Vaihda luokka">' + Object.keys(cats).map(function (k) { return '<option value="' + k + '"' + (k === m.category ? ' selected' : '') + '>' + esc(cats[k]) + '</option>'; }).join('') + '</select></div>' +
        (m.attachments.length ? '<div class="ibatt">' + m.attachments.map(function (a, i) { return '<a class="btn sm" target="_blank" rel="noopener" href="' + esc(location.pathname + '?saapunut=' + m.id + '&liite=' + i) + '">📎 ' + esc(a.name) + ' <span class="muted">' + Math.max(1, Math.round(a.size / 1024)) + ' kt</span></a>'; }).join('') + '</div>' : '') +
        '<div class="ibbody">' + esc(m.body || '(tyhjä viesti)') + '</div>';
      if (window.innerWidth <= 860) box.scrollIntoView({ block: 'start' });
      var upd = function (body, msg) {
        return api('inbox/' + m.id, { method: 'POST', body: body }).then(function () { toast(msg); return loadInbox(); }).then(function () { viewInbox(m.id); }).catch(fail);
      };
      document.getElementById('ibdone').addEventListener('click', function () { upd({ status: m.status === 'new' ? 'done' : 'new' }, m.status === 'new' ? 'Merkitty käsitellyksi' : 'Palautettu'); });
      document.getElementById('ibcat').addEventListener('change', function (e) { upd({ category: e.target.value }, 'Luokka vaihdettu'); });
      var one = function (action, msg) { api('inbox/bulk', { method: 'POST', body: { action: action, ids: [m.id] } }).then(function () { toast(msg); return loadInbox(); }).then(function () { location.hash = 'saapuneet'; viewInbox(); }).catch(fail); };
      var sp = document.getElementById('ibspam1');
      if (sp) sp.addEventListener('click', function () { one('spam', 'Siirretty roskapostiin – saman lähettäjän viestit menevät jatkossa suoraan roskapostiin'); });
      var ibo = document.getElementById('iboffer');
      if (ibo) ibo.addEventListener('click', function () {
        // Avataan asiakkaan uusin kohde, jota ei ole vielä hyväksytty, ja sen tarjouslomake.
        var ps = S.board.filter(function (p) { return p.customer_id === m.customer_id && !p.approval; }).sort(function (a, b) { return b.id - a.id; });
        if (ps[0]) S.openOffer = ps[0].id;
        location.hash = 'asiakas-' + m.customer_id;
      });
      document.getElementById('ibdel1').addEventListener('click', function () { if (confirm('Poistetaanko viesti pysyvästi?')) one('delete', 'Viesti poistettu'); });
      var l = document.getElementById('iblink');
      if (l) l.addEventListener('change', function () { if (l.value) upd({ customer_id: +l.value }, 'Viesti liitetty asiakkaaseen'); });
      var nl = document.getElementById('iblead');
      if (nl) nl.addEventListener('click', function () {
        S.prefill = { text: m.subject + '\n\n' + m.body, share: false, name: m.from_name, email: m.from_email, inboxId: m.id };
        location.hash = 'uusi';
      });
    }).catch(function (e) { var b = document.getElementById('ibcard'); if (b) b.innerHTML = '<div class="empty">' + esc(e.message) + '</div>'; });
  }

  var SOURCES = ['Puhelin', 'WhatsApp', 'Tekstiviesti', 'Messenger', 'Sähköposti', 'Messut', 'Paikan päällä', 'Roll-up tai kyltti', 'Suosittelu', 'Google-haku', 'Facebook', 'Isännöitsijä', 'Muu'];
  function viewNew(cid) {
    if (cid && (!S.newFor || S.newFor.id !== cid)) {
      main.innerHTML = head('Uusi tarjouspyyntö', 'Ladataan…');
      api('customers/' + cid).then(function (c) { S.newFor = c; viewNew(cid); }).catch(fail);
      return;
    }
    var c = cid ? S.newFor : null;
    var owners = S.users.filter(function (u) { return u.role === 'osakas'; });
    var f2 = function (name, label, type, extra) { return '<label class="fld">' + label + '<input name="' + name + '" type="' + type + '" ' + (extra || '') + '></label>'; };
    main.innerHTML = head('Uusi tarjouspyyntö', c ? 'Uusi kohde asiakkaalle ' + c.name + '.' : 'Puhelimessa, sähköpostilla, messuilla tai paikan päällä saatu tarjouspyyntö. Verkkosivun lomakkeelta ne tulevat automaattisesti.') +
      '<form class="card" id="nc">' +
      '<label class="fld wide paste">Liitä asiakkaan viesti <span class="muted small">(WhatsApp, tekstiviesti, Messenger, sähköposti: puhelin, sähköposti, osoite ja tuotteet poimitaan kenttiin)</span>' +
        '<textarea name="paste" rows="4" placeholder="Pitkä painallus viestiin → Kopioi, ja liitä tähän"></textarea></label><div id="parsed" class="parsed" hidden></div>' +
      (c ? '<p><b>' + esc(c.name) + '</b><br><span class="muted">' + esc([c.phone, c.email].filter(Boolean).join(' · ')) + '</span></p>' :
        '<h2>Asiakas</h2><div class="fields">' + f2('name', 'Nimi *', 'text', 'required autocomplete="off"') + f2('phone', 'Puhelin', 'tel') + f2('email', 'Sähköposti', 'email') + '</div>') +
      '<h2 class="mt">Kohde</h2><div class="fields">' +
      f2('address', 'Kohteen katuosoite', 'text', c ? 'value="' + esc(c.address) + '"' : '') + f2('city', 'Paikkakunta', 'text', c ? 'value="' + esc(c.city) + '"' : '') +
      f2('title', 'Tuotteet', 'text', 'placeholder="esim. 8 ikkunaa ja ulko-ovi"') +
      '<label class="fld">Toimitustapa<select name="delivery">' + Object.keys(S.deliveries).map(function (k) { return '<option value="' + k + '">' + esc(S.deliveries[k]) + '</option>'; }).join('') + '</select></label>' +
      '<div class="terms small wide" id="mterms" hidden>' + esc(S.measureTerms) + '</div>' +
      '<label class="fld wide">Mitä asiakas tarvitsee<textarea name="message" rows="3" placeholder="Talon ikä, ikkunoiden määrä, toiveet, aikataulu…"></textarea></label>' +
      '<label class="fld">Mistä asiakas tuli<select name="source">' + SOURCES.map(function (x) { return '<option>' + x + '</option>'; }).join('') + '</select></label>' +
      '<label class="fld" id="refw" hidden>Suosittelija<select name="referrer_id"><option value="">Valitse asiakas</option>' +
        S.customers.filter(function (x) { return !c || x.id !== c.id; }).map(function (x) { return '<option value="' + x.id + '">' + esc(x.name) + (x.city ? ', ' + esc(x.city) : '') + '</option>'; }).join('') + '</select></label>' +
      (isOwner() && !c ? '<label class="fld">Vastuumyyjä<select name="owner_id">' + opt(owners, S.me.id) + '</select></label>' : '') +
      '</div><h2 class="mt">Seuraava askel</h2><div class="choices">' +
      '<label><input type="radio" name="task" value="call" checked><span id="calltxt">Soita ja sovi mittaus (tehtävä seuraavalle arkipäivälle)</span></label>' +
      '<label id="measw"><input type="radio" name="task" value="measure"><span>Mittauskäynti on jo sovittu</span></label>' +
      '<input class="date" type="date" name="measure_date" aria-label="Mittauspäivä">' +
      '<label><input type="radio" name="task" value="none"><span>Ei tehtävää</span></label>' +
      '<label class="mt"><input type="checkbox" name="send_link" checked><span>Lähetä asiakkaalle kiitosviesti ja Oma kohde -linkki <span class="muted small">(vaatii sähköpostin)</span></span></label>' +
      '</div><div class="actions"><button class="btn p">Tallenna tarjouspyyntö</button>' + (c ? '<a class="btn" href="#asiakas-' + c.id + '">Peruuta</a>' : '') + '</div></form>';
    var form = document.getElementById('nc');
    function applyParsed(text, fromShare) {
      var p = parseMessage(text), got = [];
      var set = function (k, label) {
        if (!form[k] || !p[k]) return;
        if (form[k].value && !form[k].dataset.auto) return; // käsin kirjoitettua ei ylikirjoiteta
        form[k].value = p[k]; form[k].dataset.auto = '1'; got.push(label);
      };
      if (!c) { set('name', 'nimi'); set('phone', 'puhelin'); set('email', 'sähköposti'); }
      set('address', 'osoite'); set('city', 'paikkakunta'); set('title', 'tuotteet');
      if (p.delivery) { form.delivery.value = p.delivery; onDelivery(); got.push('toimitustapa'); }
      if (p.message && (!form.message.value || form.message.dataset.auto)) { form.message.value = p.message; form.message.dataset.auto = '1'; }
      if (p.whatsapp || fromShare) form.source.value = 'WhatsApp';
      else if (p.email && !p.phone) form.source.value = 'Sähköposti';
      var box = document.getElementById('parsed'), ex = !c && findExisting(p);
      box.hidden = false;
      box.innerHTML = (got.length ? 'Poimittiin: <b>' + esc(got.join(', ')) + '</b>. Tarkista kentät ennen tallennusta.' : 'Viestistä ei löytynyt yhteystietoja. Täydennä kentät käsin.') +
        (fromShare ? ' Lähteeksi valittiin WhatsApp, vaihda tarvittaessa.' : '') +
        (ex ? '<br>Sama ' + (p.email && ex.email && ex.email.toLowerCase() === p.email ? 'sähköposti' : 'puhelinnumero') + ' on jo asiakkaalla <b>' + esc(ex.name) + '</b>. <a href="#uusi-' + ex.id + '" id="useex">Lisää kohde hänelle</a>' : '');
      var u = document.getElementById('useex');
      if (u) u.addEventListener('click', function () { S.prefill = { text: form.paste.value, share: fromShare }; });
    }
    form.paste.addEventListener('input', function () { applyParsed(form.paste.value, false); });
    form.addEventListener('input', function (e) { if (e.target !== form.paste && e.target.dataset) delete e.target.dataset.auto; });
    var fromInbox = null;
    if (S.prefill) {
      var pf = S.prefill; S.prefill = null; form.paste.value = pf.text; applyParsed(pf.text, pf.share);
      if (pf.email && !c) { form.email.value = pf.email; form.source.value = 'Sähköposti'; }
      if (pf.name && !c && !form.name.value) form.name.value = pf.name;
      fromInbox = pf.inboxId || null;
    }
    form.source.addEventListener('change', function () { document.getElementById('refw').hidden = form.source.value !== 'Suosittelu'; });
    function onDelivery() {
      var own = form.delivery.value === 'omat_mitat';
      document.getElementById('mterms').hidden = !own || !S.measureTerms;
      document.getElementById('measw').hidden = own; form.measure_date.hidden = own;
      if (own && form.task.value === 'measure') form.task.value = 'call';
      document.getElementById('calltxt').textContent = (own ? 'Soita ja pyydä mitat' : 'Soita ja sovi mittaus') + ' (tehtävä seuraavalle arkipäivälle)';
    };
    form.delivery.addEventListener('change', onDelivery);
    form.measure_date.addEventListener('focus', function () { form.task.value = 'measure'; });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var body = { customer_id: c ? c.id : 0, task: form.task.value, send_link: form.send_link.checked };
      ['address', 'city', 'title', 'message', 'source', 'delivery'].forEach(function (k) { body[k] = form[k].value; });
      if (!c) ['name', 'phone', 'email'].forEach(function (k) { body[k] = form[k].value.trim(); });
      if (!c && !body.phone && !body.email) { toast('Anna puhelinnumero tai sähköposti', true); return; }
      if (body.source === 'Suosittelu' && form.referrer_id.value) body.referrer_id = +form.referrer_id.value;
      if (body.task === 'measure') {
        if (!form.measure_date.value) { toast('Valitse mittauspäivä', true); return; }
        body.measure_date = form.measure_date.value;
      }
      if (form.owner_id) body.owner_id = +form.owner_id.value;
      form.querySelector('button.p').disabled = true;
      api('customers', { method: 'POST', body: body }).then(function (r) {
        toast(r.existing ? 'Kohde lisätty olemassa olevalle asiakkaalle' : 'Tarjouspyyntö tallennettu' + (r.mailed ? ', linkki lähetetty' : ''));
        if (fromInbox) { api('inbox/' + fromInbox, { method: 'POST', body: { customer_id: r.id, status: 'done' } }).then(function () { S.inbox = null; }); }
        S.newFor = null;
        return Promise.all([api('board').then(function (b) { S.board = b; }), api('tasks').then(function (t) { S.tasks = t; }), loadCustomers()]).then(function () { location.hash = 'asiakas-' + r.id; });
      }).catch(function (err) { form.querySelector('button.p').disabled = false; fail(err); });
    });
  }

  /* ---------- Laskuri (ilman asiakasta: pikalaskelma ja PDF) ---------- */
  function saveCalcTemplate(tpl) {
    return api('calc-template', { method: 'POST', body: tpl }).then(function (t) { S.calcTemplate = t; toast('Omat rivit ja järjestys tallennettu pohjaksi'); }).catch(function (e) { fail(e); throw e; });
  }
  function savePdf(blob, name) {
    var a = document.createElement('a'), u = URL.createObjectURL(blob);
    a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
  }
  function viewCalc() {
    main.innerHTML = head('Laskuri', 'Laske hinta ja tee PDF. Asiakkaalle lähetettävä tarjous tehdään asiakkaan kortilta: Lähetä tarjous → Laskuri.') +
      '<div class="card"><div id="calcbox"></div><div class="actions" style="margin-top:12px"><button type="button" class="btn p" id="calcpdf">Lataa PDF</button></div></div>';
    var L = window.NAPLaskuri.mount(document.getElementById('calcbox'), { laskija: S.me.name, jspdf: C.jspdf, template: S.calcTemplate, onSaveTemplate: isOwner() ? saveCalcTemplate : null });
    var b = document.getElementById('calcpdf');
    L.onChange(function (c) { b.disabled = !c.items.length; });
    b.addEventListener('click', function () {
      b.disabled = true;
      L.pdf({}).then(function (blob) { savePdf(blob, L.fileName()); b.disabled = false; }).catch(function (e) { b.disabled = false; fail(e); });
    });
  }

  function render() {
    var r = route();
    drawNav(r.v);
    if (r.v === 'putki') return viewBoard();
    if (r.v === 'asiakkaat') return viewCustomers(r.id);
    if (r.v === 'tehtavat') return viewTasks();
    if (r.v === 'laskuri') return viewCalc();
    if (r.v === 'uusi') return viewNew(r.id);
    if (r.v === 'kalenteri' && window.NAPV.visits) return r.visit ? window.NAPV.visits.viewVisit(r.visit) : window.NAPV.visits.viewCalendar(r.week);
    if (r.v === 'saapuneet' && isOwner()) return viewInbox(r.id);
    return viewDay();
  }
  window.addEventListener('hashchange', function () { if (!S.me) return; render(); window.scrollTo(0, 0); });

  window.NAPV = { S: S, esc: esc, api: api, toast: toast, fail: fail, head: head, fdate: fdate, isOwner: isOwner, user: user, uname: uname, opt: opt,
    main: function () { return main; }, render: function () { render(); },
    reloadBoard: function () { return Promise.all([api('board'), api('tasks')]).then(function (r) { S.board = r[0]; S.tasks = r[1]; drawNav(route().v); }); } };

  api('bootstrap').then(function (b) {
    S.me = b.me; S.users = b.users; S.stages = b.stages; S.today = b.today; S.offerDays = b.offer_days || 30; S.deliveries = b.deliveries || {}; S.measureTerms = b.measure_terms || ''; S.calcTemplate = b.calc_template || null;
    return Promise.all([api('board'), api('tasks'), api('customers')]);
  }).then(function (r) {
    S.board = r[0]; S.tasks = r[1]; S.customers = r[2];
    if (isOwner()) api('inbox?status=new').then(function (x) { S.inboxNew = inboxNewCount(x.counts, x.hidden); drawNav(route().v); }).catch(function () {});
    // Androidin Jaa-valikko: /crm/?jaa_teksti=... → Uusi tarjouspyyntö viesti valmiiksi liitettynä
    var q = new URLSearchParams(location.search), shared = [q.get('jaa_otsikko'), q.get('jaa_teksti'), q.get('jaa_linkki')].filter(Boolean).join('\n');
    if (shared) {
      S.prefill = { text: shared, share: true };
      history.replaceState(null, '', location.pathname + '#uusi');
    }
    render();
  })
    .catch(function (e) { main.innerHTML = '<div class="empty">CRM:n lataus epäonnistui: ' + esc(e.message) + ' Päivitä sivu tai kirjaudu uudelleen.</div>'; });
})();
